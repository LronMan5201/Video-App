package com.example.boxuegu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.example.boxuegu.MainActivity;
import com.example.boxuegu.R;

import java.util.Timer;
import java.util.TimerTask;

public class SplashActivity extends AppCompatActivity {

    private TextView tv_version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        init();//执行方法
    }
    private void init(){
        //获取显示版本号的信息控件
        tv_version = findViewById(R.id.tv_version);
        try {
            //获取Packagemanager对象,获取程序包信息,packagename传入程序的包名,0(获取程序包的标识）
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(),0);
            //讲版本号信息放在界面上,通过info对象来获取的
            tv_version.setText("V"+info.versionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            tv_version.setText("V");
        }
        //通过timer类和TimerTask类
        Timer timer = new Timer();
        //实现匿名内部类
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                //跳转到主界面
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                //开启主界面
                startActivity(intent);
                //关闭欢迎界面
                SplashActivity.this.finish();
            }
        };
        //执行任务 设置程序延迟3秒后主动执行task任务
        timer.schedule(task,3000);
    }
}
