package com.example.boxuegu.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.boxuegu.R;
import com.example.boxuegu.utils.UtilsHelper;

public class RegisterActivity extends AppCompatActivity {

    private TextView tv_main_title,tv_back;//标题与"返回"按钮
    private RelativeLayout rl_title_bar;//标题栏布局
    private Button btn_register;//注册按钮
    private EditText et_user_name,et_psw_again,et_psw;//用户名，密码，再次输入密码的控件
    private String userName,psw,pswAgain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //调用方法
        init();
        getEditString();
    }
    //获取界面的控件
    private void init(){
        //获取id
        tv_main_title = findViewById(R.id.tv_main_title);
        //设置界面的标题
        tv_main_title.setText("注册");
        //获取返回按钮和标题栏
        tv_back = findViewById(R.id.tv_back);
        rl_title_bar = findViewById(R.id.title_bar);
        //设置标题栏的背景
        rl_title_bar.setBackgroundColor(Color.TRANSPARENT);
        //获取3个按钮和注册
        btn_register=findViewById(R.id.btn_register);
        et_user_name=findViewById(R.id.et_user_name);
        et_psw=findViewById(R.id.et_psw);
        et_psw_again=findViewById(R.id.et_psw_again);
    }
    //获取界面控件中注册件信息
    private void getEditString(){
        //获取注册界面中输入的用户名信息
        userName = et_user_name.getText().toString().trim();
        //获取注册界面输入的密码信息
        psw = et_psw.getText().toString().trim();
        //获取注册界面再次输入的密码信息
        pswAgain = et_psw_again.getText().toString().trim();
        //返回按钮的点击事件
        tv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //关闭注册界面
                RegisterActivity.this.finish();
            }
        });
        //注册按钮的点击事件
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获取界面上输入的注册信息
                getEditString();
                //判断获取的注册信息是否为空
                //判断用户名
                if (TextUtils.isEmpty(userName)) {
                    Toast.makeText(RegisterActivity.this, "请输入用户名", Toast.LENGTH_SHORT).show();
                    return;
                    //判断两次输入的密码是否为空
                }else if(TextUtils.isEmpty(psw)){
                    Toast.makeText(RegisterActivity.this,"请输入密码",Toast.LENGTH_SHORT).show();
                    return;
                }else if (TextUtils.isEmpty(pswAgain)){
                    Toast.makeText(RegisterActivity.this,"请再次输入密码",Toast.LENGTH_SHORT).show();
                    return;
                }else if (!psw.equals(pswAgain)){
                    Toast.makeText(RegisterActivity.this,"输入两次的密码不一致",Toast.LENGTH_SHORT).show();
                    return;
                }else if (UtilsHelper.isExistUserName(RegisterActivity.this,userName)){
                    Toast.makeText(RegisterActivity.this,"此用户名已经存在",Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    Toast.makeText(RegisterActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
                    //把用户名和密码保存到Sharedpreferences文件中,第一个上下文,第二个要保存的用户名,第3个密码
                    UtilsHelper.saveUserInfo(RegisterActivity.this,userName,psw);
                    //注册成功后把用户名传递到LoginActivity中
                    Intent data = new Intent();
                    //封装要保存的用户名
                    data.putExtra("userName",userName);
                    //传递信息
                    setResult(RESULT_OK,data);
                    //关闭注册界面
                    RegisterActivity.this.finish();

                }


            }
        });
    }
}