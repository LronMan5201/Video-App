package com.example.boxuegu.activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.boxuegu.R;
import com.example.boxuegu.utils.MD5Utils;
import com.example.boxuegu.utils.UtilsHelper;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private TextView tv_main_title,tv_back,tv_register,tv_find_psw;
    private Button btn_login;
    private EditText et_user_name,et_psw;
    private String userName,psw,spPsw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        init();
    }
    private void init(){
        tv_main_title = findViewById(R.id.tv_main_title);
        tv_main_title.setText("登录");
        //获取返回按钮控件
        tv_back = findViewById(R.id.tv_back);
        //获取立即注册按钮控件
        tv_register = findViewById(R.id.tv_register);
        //获取找回密码按钮控件
        tv_find_psw = findViewById(R.id.tv_find_psw);
        //获取登录
        btn_login = findViewById(R.id.btn_login);
        //获取用户名输入框
        et_user_name = findViewById(R.id.et_user_name);
        //获取密码输入框
        et_psw = findViewById(R.id.et_psw);

        //设置返回按钮的监听器
        tv_back.setOnClickListener(this);
        //立即注册
        tv_register.setOnClickListener(this);
        //找回密码
        tv_find_psw.setOnClickListener(this);
        //登录按钮
        btn_login.setOnClickListener(this);


    }//接受注册用户会传过来的信息
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //判断从注册界面传过来的数据data是否为null
        if(data != null){
             //从注册界面回传过来的用户名
            String userName = data.getStringExtra("userName");
            //判断回传过来的用户名是否为空
            if(TextUtils.isEmpty(userName)){
                //将回传过来的用户名信息显示到登录界面上
                et_user_name.setText(userName);
                //设置输入框光标的位置  将光标的位置设置在用户名信息的后面来进行显示的
                et_user_name.setSelection(userName.length());
            }
        }
    }
    //实现登录界面控件的点击事件
    @Override
    public void onClick(View view) {
        switch (view.getId()){//判读是界面上的那个控件
            //如果点击的是返回按钮,调用finish关闭当前的界面
            case R.id.tv_back:
                this.finish();
                break;
            //立即注册文本的点击事件
            case R.id.tv_register:
                 //跳转到注册界面
                 Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                 //获取注册回传过来的用户名
                 startActivityForResult(intent,1);
                 break;
            //找回密码的点击事件
            case R.id.tv_find_psw:
                //跳转到找回密码界面
                break;
            //登录按钮的点击事件
            case R.id.btn_login:
                 //获取用户名输入框和密码输入框的一些信息 trim就是去掉输入框输入的一些空格信息
                userName = et_user_name.getText().toString().trim();
                //获取密码
                psw = et_psw.getText().toString().trim();
                //后期要判断密码是否与本地的密码一致 ,所以要将获取的密码来经过MD5加密
                String md5Psw = MD5Utils.md5(psw);
                //根据输入的用户名信息，来获取从本地文件中是否有对应的密码信息
                 spPsw = UtilsHelper.readPsw(LoginActivity.this,userName);
                //判断用户名和密码是否为空
                if (TextUtils.isEmpty(userName)){
                    //如果界面上输入的信息为空，那么要调用Toast提示用户输入用户名 第三个参数是显示时间
                    Toast.makeText(LoginActivity.this,"请输入用户名",Toast.LENGTH_SHORT).show();
                    return;
                }//判断根据用户名获取的本地文件中的密码信息是否为空
                else if (TextUtils.isEmpty(spPsw)){
                    Toast.makeText(LoginActivity.this," 此用户名不存在",Toast.LENGTH_SHORT).show();
                     return;
                }//判断界面上输入的密码是否为空
                else if(TextUtils.isEmpty(psw)){
                    Toast.makeText(LoginActivity.this,"请输入密码",Toast.LENGTH_SHORT).show();
                    return;
                }//如果都不为空，判断获取的密码是否与本地密码是一样的
                else if (!TextUtils.isEmpty(spPsw)){
                    Toast.makeText(LoginActivity.this,"请输入用户名",Toast.LENGTH_SHORT).show();
                    return;
                }//判断加密后的密码与本地获取的密码是否是一样的
                else if (!TextUtils.isEmpty(spPsw) && ! md5Psw.equals(spPsw)){
                    Toast.makeText(LoginActivity.this,"输入的密码不正确", Toast.LENGTH_SHORT).show();
                    return;
                }//如果两个密码都一致
                else if (md5Psw.equals(spPsw)){
                    Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_SHORT).show();
                    //保存登录的状态与用户名
                     UtilsHelper.saveLoginStatus(LoginActivity.this, true,userName);
                     //将登录成功后的状态传递到
                     Intent data = new Intent();
                     data.putExtra("isLogin",true);
                     //回传数据信息
                    setResult(RESULT_OK,data);
                    //关闭LoginActivity界面
                    LoginActivity.this.finish();
                    return;
                }
                break;



        }
    }
}