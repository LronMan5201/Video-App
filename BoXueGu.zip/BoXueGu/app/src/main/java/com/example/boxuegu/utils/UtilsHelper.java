package com.example.boxuegu.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.w3c.dom.Text;

public class UtilsHelper {
    //判断本地文件中是否有要保存的用户名,如果boolean为true说明本地文件存在当前要保存的用户名信息
    public static boolean isExistUserName(Context context, String userName){  //context上下文
        //记录当前文件是否有用户要保存的信息，默认不保存
        boolean hase_userName = false;
        //获取对象  第一个参数要保存文件的名称，第二个是第一个的默认操作模式,表示保存文件的是私有的，只能被本应用访问，在这个模式下写入的内容，会覆盖文件中原有的内容
        SharedPreferences sp = context.getSharedPreferences("loginInfo",Context.MODE_PRIVATE);
        //获取userName 根据存入的用户名的信息来获取对应的密码信息
        String spPsw = sp.getString(userName,"");
        //判断获取的密码是否为空 如果不为空说明当前要保存的用户名已经保存过了
        if (!TextUtils.isEmpty(spPsw)){
            hase_userName = true;
        }
        return hase_userName;
            //否则当前要保存的用户名还没有保存
    }

    //保存用户名和密码的信息
    public static void saveUserInfo(Context context, String userName,String psw){  //context上下文
        //加密密码
        String md5psw = MD5Utils.md5(psw);
        //获取对象  第一个参数要保存文件的名称，第二个是第一个的默认操作模式,表示保存文件的是私有的，只能被本应用访问，在这个模式下写入的内容，会覆盖文件中原有的内容
        SharedPreferences sp = context.getSharedPreferences("loginInfo",Context.MODE_PRIVATE);
        //获取编辑器对象editor
        SharedPreferences.Editor editor = sp.edit();
        //保存用户名和加密后的密码
        editor.putString(userName,md5psw);
        //提交保存信息
        editor.commit();
    }//读取用户的密码信息  根据用户名获取loginInfo文件 获取用户名对应的密码信息
    public static String readPsw(Context context,String userName){
        SharedPreferences sp = context.getSharedPreferences("loginInfo",Context.MODE_PRIVATE);
        String spPsw = sp.getString(userName,"");
        //将获取的密码信息返回
        return spPsw;
    }//创建一个方法保存登录状态和用户名
    public static void saveLoginStatus(Context context,boolean status,String userName){
        SharedPreferences sp = context.getSharedPreferences("loginInfo",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        //封装要存放的数据信息isLogin登录的状态
        editor.putBoolean("isLogin",status);
        //存入登录用户名
        editor.putString("loginUserName",userName);
        editor.commit();//提交保存信息
    }
}
